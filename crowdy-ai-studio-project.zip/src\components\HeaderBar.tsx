import React from 'react';
import { UserProfile, Friend } from '../types';
import { User, UserPlus, Radio, Building2, Download } from 'lucide-react';

interface HeaderBarProps {
  currentUser: UserProfile;
  activeFriend: Friend | null;
  groupCode: string;
  isGpsLive: boolean;
  gpsAccuracy?: number;
  userLat?: number;
  userLng?: number;
  onOpenAuthFriends: () => void;
  onChangeGroupCode: () => void;
  onToggleGps: () => void;
  onSetCustomLocation: (lat: number, lng: number, label: string) => void;
  onOpenIndoorCalibration: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  currentUser,
  activeFriend,
  groupCode,
  isGpsLive,
  gpsAccuracy,
  userLat,
  userLng,
  onOpenAuthFriends,
  onChangeGroupCode,
  onToggleGps,
  onSetCustomLocation,
  onOpenIndoorCalibration,
}) => {
  const handlePresetSelect = () => {
    const choice = prompt(
      '원하시는 테스트 장소를 선택하거나 번호를 입력하세요:\n' +
        '1. 현재 내 실제 GPS 위치로 설정\n' +
        '2. 부산항 국제여객터미널\n' +
        '3. 서울역\n' +
        '4. 서울 강남역\n' +
        '5. 홍대입구역\n' +
        '6. 부산 해운대\n' +
        '7. 대구 동성로',
      '1'
    );

    if (choice === '1') {
      onToggleGps();
    } else if (choice === '2') {
      onSetCustomLocation(35.1182, 129.0478, '부산항 국제여객터미널');
    } else if (choice === '3') {
      onSetCustomLocation(37.5559, 126.9723, '서울역');
    } else if (choice === '4') {
      onSetCustomLocation(37.4979, 127.0276, '서울 강남역');
    } else if (choice === '5') {
      onSetCustomLocation(37.5563, 126.9228, '홍대입구역');
    } else if (choice === '6') {
      onSetCustomLocation(35.1587, 129.1604, '부산 해운대');
    } else if (choice === '7') {
      onSetCustomLocation(35.8694, 128.5942, '대구 동성로');
    }
  };
  return (
    <header className="w-full bg-white border-b border-slate-100 shrink-0 z-20">
      {/* Top Brand Bar */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <span className="w-3 h-3 rounded-full bg-[#c9ff51] inline-block shadow-[6px_0_0_#7054db]" />
          </div>
          <div>
            <div className="text-lg font-black tracking-tight text-[#111a35] flex items-center gap-1.5">
              Crowdy
              <span className="text-[10px] bg-[#f0edff] text-[#7054db] px-2 py-0.5 rounded-full font-bold">
                AR 일행 찾기
              </span>
            </div>
            <p className="text-[10px] text-slate-500 font-medium leading-none mt-0.5">
              사람 많은 곳에서도, 우리는 다시 만난다.
            </p>
          </div>
        </div>

        {/* User Profile / Group Tag Button */}
        <div className="flex items-center gap-1.5">
          <a
            href="/project-source.zip"
            download="Crowdy_SourceCode.zip"
            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-extrabold px-2.5 py-1.5 rounded-full border border-emerald-200 transition-colors flex items-center gap-1 shadow-xs"
            title="프로젝트 전체 소스코드 ZIP 다운로드"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden sm:inline">소스코드</span> ZIP
          </a>

          <button
            id="group-code-btn"
            onClick={onChangeGroupCode}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3 py-1.5 rounded-full transition-colors flex items-center gap-1"
          >
            #{groupCode}
          </button>

          <button
            id="auth-friends-btn"
            onClick={onOpenAuthFriends}
            className="flex items-center gap-1.5 bg-[#111a35] text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-sm hover:bg-slate-800 transition-all"
          >
            <User className="w-3.5 h-3.5 text-[#c9ff51]" />
            <span>{currentUser.isLoggedIn ? currentUser.name : '로그인'}</span>
            <UserPlus className="w-3 h-3 text-slate-300 ml-0.5" />
          </button>
        </div>
      </div>

      {/* GPS Status Indicator Bar */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-slate-50 text-[11px] border-t border-slate-100 text-slate-600">
        <div className="flex items-center gap-2 overflow-hidden pr-2">
          <span
            className={`w-2.5 h-2.5 rounded-full shrink-0 ${
              isGpsLive
                ? 'bg-emerald-500 animate-pulse shadow-[0_0_0_3px_#e0f8e9]'
                : 'bg-amber-400'
            }`}
          />
          <span className="font-bold text-slate-800 shrink-0">
            {isGpsLive ? '실시간 GPS 활성' : '데모 시뮬레이션'}
          </span>
          <span className="text-slate-400 truncate">
            {isGpsLive
              ? `정확도 ±${Math.round(gpsAccuracy || 15)}m`
              : '실제 GPS 허용 시 현장 실시간 추적'}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            id="indoor-calib-btn"
            onClick={onOpenIndoorCalibration}
            className="font-bold text-[10px] bg-[#7054db] text-white px-2 py-1 rounded-lg hover:bg-indigo-700 transition-all flex items-center gap-1 active:scale-95 shadow-sm"
            title="실내 GPS 오차 및 방향 보정"
          >
            <Building2 className="w-3 h-3 text-[#c9ff51]" />
            <span>실내 보정</span>
          </button>

          <button
            id="location-picker-btn"
            onClick={handlePresetSelect}
            className="font-bold text-[10px] bg-slate-200 text-slate-800 px-2 py-1 rounded-lg hover:bg-slate-300 transition-all flex items-center gap-1 active:scale-95"
          >
            <span>장소 변경</span>
          </button>

          <button
            id="gps-toggle-btn"
            onClick={onToggleGps}
            className="font-bold text-[10px] bg-[#c9ff51] text-[#111a35] px-2.5 py-1 rounded-lg hover:bg-[#b5f03a] transition-all flex items-center gap-1 shadow-sm active:scale-95"
          >
            <Radio className="w-3 h-3 text-[#7054db]" />
            <span>내 GPS 위치로 이동</span>
          </button>
        </div>
      </div>
    </header>
  );
};
