import { UserLocation } from '../types';

/**
 * Calculates distance between two coordinates in meters using Haversine formula
 */
export function getDistanceInMeters(p1: UserLocation, p2: UserLocation): number {
  const R = 6371000; // Earth radius in meters
  const rad = (x: number) => (x * Math.PI) / 180;
  
  const dLat = rad(p2.lat - p1.lat);
  const dLng = rad(p2.lng - p1.lng);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(rad(p1.lat)) * Math.cos(rad(p2.lat)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calculates bearing (heading angle) from p1 to p2 in degrees (0 - 360)
 */
export function getBearing(p1: UserLocation, p2: UserLocation): number {
  const rad = (x: number) => (x * Math.PI) / 180;
  const deg = (x: number) => (x * 180) / Math.PI;

  const y = Math.sin(rad(p2.lng - p1.lng)) * Math.cos(rad(p2.lat));
  const x =
    Math.cos(rad(p1.lat)) * Math.sin(rad(p2.lat)) -
    Math.sin(rad(p1.lat)) * Math.cos(rad(p2.lat)) * Math.cos(rad(p2.lng - p1.lng));

  return (deg(Math.atan2(y, x)) + 360) % 360;
}

/**
 * Formats meter distance to human readable format
 */
export function formatDistance(meters: number): string {
  if (isNaN(meters) || meters === null) return '--m';
  if (meters < 1000) {
    return `${Math.round(meters)}m`;
  }
  return `${(meters / 1000).toFixed(1)}km`;
}

/**
 * Generates festival landmark places relative to given base coordinate
 */
export function getFestivalPlaces(baseLat: number = 37.5665, baseLng: number = 126.9780) {
  return [
    {
      id: 'spot-stage',
      title: 'MAIN STAGE',
      category: '공연 무대',
      lat: baseLat + 0.0006,
      lng: baseLng - 0.0005,
      bgColor: '#111a35',
      textColor: '#c9ff51',
      icon: '🎤',
      description: '메인 가수 축하 공연 및 스피커 존',
    },
    {
      id: 'spot-food',
      title: 'FOOD & DRINKS',
      category: '푸드트럭 존',
      lat: baseLat - 0.0005,
      lng: baseLng + 0.0006,
      bgColor: '#f04e62',
      textColor: '#ffffff',
      icon: '🍔',
      description: '타코, 수제맥주 및 음료 푸드존',
    },
    {
      id: 'spot-market',
      title: 'ART MARKET',
      category: '굿즈/마켓',
      lat: baseLat - 0.0008,
      lng: baseLng - 0.0007,
      bgColor: '#7054db',
      textColor: '#ffffff',
      icon: '🎨',
      description: '아티스트 굿즈 및 핸드메이드 마켓',
    },
    {
      id: 'spot-info',
      title: '2번 출입구 안내소',
      category: '추천 만남장소',
      lat: baseLat + 0.0004,
      lng: baseLng + 0.0007,
      bgColor: '#4ac987',
      textColor: '#111a35',
      icon: '⌂',
      description: '밝고 안전요원이 상주하는 공식 안내소',
    },
  ];
}

export function getInitialDemoFriends(baseLat: number = 37.5665, baseLng: number = 126.9780) {
  return [
    {
      id: 'f-1',
      name: '스마트폰 1번',
      code: 'PHONE01',
      isOnline: true,
      avatarBg: '#b4ff45',
      avatarInitial: '1',
      location: {
        lat: baseLat + 0.00085,
        lng: baseLng + 0.00075,
        accuracy: 12,
      },
      battery: 88,
      statusMessage: '실시간 위치 이동 중',
    },
    {
      id: 'f-2',
      name: '스마트폰 2번',
      code: 'PHONE02',
      isOnline: true,
      avatarBg: '#c8b6ff',
      avatarInitial: '2',
      location: {
        lat: baseLat - 0.00065,
        lng: baseLng - 0.00095,
        accuracy: 18,
      },
      battery: 45,
      statusMessage: '약속 장소 대기 중',
    },
    {
      id: 'f-3',
      name: '스마트폰 3번',
      code: 'PHONE03',
      isOnline: false,
      avatarBg: '#ffae92',
      avatarInitial: '3',
      location: {
        lat: baseLat + 0.0012,
        lng: baseLng - 0.0004,
        accuracy: 25,
      },
      battery: 15,
      statusMessage: '이동 중 (배터리 15%)',
    },
  ];
}
