import React from 'react';
import { ActiveTab } from '../types';
import { Compass, Navigation, Sparkles, ShieldAlert, Users } from 'lucide-react';

interface BottomNavBarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  onOpenSos: () => void;
  onOpenFriends: () => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  onOpenSos,
  onOpenFriends,
}) => {
  return (
    <div className="relative w-full bg-white border-t border-slate-100 shrink-0 z-20">
      <div className="flex items-center justify-around h-16 px-2 pr-16">
        {/* Tab 1: Map */}
        <button
          id="nav-tab-map"
          onClick={() => onTabChange('map')}
          className={`flex flex-col items-center justify-center gap-1 transition-all px-3 py-1.5 rounded-xl ${
            activeTab === 'map'
              ? 'text-[#7054db] font-black'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Compass className="w-5 h-5" />
          <span className="text-[10px]">지도</span>
        </button>

        {/* Tab 2: AR Camera */}
        <button
          id="nav-tab-ar"
          onClick={() => onTabChange('ar')}
          className={`flex flex-col items-center justify-center gap-1 transition-all px-3 py-1.5 rounded-xl ${
            activeTab === 'ar'
              ? 'text-[#7054db] font-black'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Navigation className="w-5 h-5" />
          <span className="text-[10px]">AR로 찾기</span>
        </button>

        {/* Tab 3: Smart Meeting Point */}
        <button
          id="nav-tab-meet"
          onClick={() => onTabChange('meet')}
          className={`flex flex-col items-center justify-center gap-1 transition-all px-3 py-1.5 rounded-xl ${
            activeTab === 'meet'
              ? 'text-[#7054db] font-black'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span className="text-[10px]">만남 장소</span>
        </button>

        {/* Tab 4: Friends List */}
        <button
          id="nav-tab-friends"
          onClick={onOpenFriends}
          className="flex flex-col items-center justify-center gap-1 text-slate-400 hover:text-slate-600 transition-all px-3 py-1.5"
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px]">일행 관리</span>
        </button>
      </div>

      {/* Floating SOS Button */}
      <button
        id="sos-trigger-btn"
        onClick={onOpenSos}
        className="absolute right-4 bottom-3 w-12 h-12 rounded-full bg-[#f04e62] hover:bg-rose-600 text-white font-black text-xs shadow-lg shadow-rose-500/40 flex items-center justify-center active:scale-90 transition-transform z-30"
      >
        SOS
      </button>
    </div>
  );
};
