import React from 'react';
import { Sliders, Compass, Move, RotateCcw, Building2, Check, AlertCircle, Info } from 'lucide-react';

interface IndoorCalibrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  gpsAccuracy?: number;
  isGpsLive: boolean;
  headingOffset: number;
  onHeadingOffsetChange: (offset: number) => void;
  onMicroMove: (dLat: number, dLng: number) => void;
  overrideDistance: number | null;
  onSetOverrideDistance: (dist: number | null) => void;
  onResetCalibration: () => void;
}

export const IndoorCalibrationModal: React.FC<IndoorCalibrationModalProps> = ({
  isOpen,
  onClose,
  gpsAccuracy = 20,
  isGpsLive,
  headingOffset,
  onHeadingOffsetChange,
  onMicroMove,
  overrideDistance,
  onSetOverrideDistance,
  onResetCalibration,
}) => {
  if (!isOpen) return null;

  // Approximate meters to lat/lng degrees (1m approx 0.000009 deg)
  const STEP_1M = 0.000009;
  const STEP_5M = 0.000045;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="bg-[#111a35] text-white w-full max-w-md rounded-t-3xl sm:rounded-3xl border border-slate-700 p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#7054db]/20 text-[#c9ff51] rounded-xl border border-[#7054db]/40">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-1.5">
                실내 / 현장 오차 보정 도구
              </h2>
              <p className="text-[11px] text-slate-400">
                실내 GPS 반사 및 나침반 센서 교란 즉시 조절
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Indoor Notice Banner */}
        <div className="mt-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start gap-2 text-xs text-amber-200">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed text-[11px]">
            <span className="font-bold text-amber-300">실내 오차 안내:</span> 건물 안, 복도, 공연장 내부에서는 콘크리트 벽체로 인해 GPS 오차가 커지거나 나침반 방향이 가리키는 곳이 엇갈릴 수 있습니다. 아래 조절기로 미세 위치와 방향을 보정하세요.
          </p>
        </div>

        {/* GPS Live Status */}
        <div className="mt-4 p-3 bg-slate-800/80 rounded-2xl flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${isGpsLive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span className="font-bold text-slate-200">
              {isGpsLive ? '현재 실시간 GPS 사용 중' : '데모 시뮬레이션 상태'}
            </span>
          </div>
          <span className="text-slate-400 font-mono text-[11px]">
            오차 ±{Math.round(gpsAccuracy)}m
          </span>
        </div>

        {/* 1. Micro Position Fine-Tuning (Direction Pad) */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1">
              <Move className="w-3.5 h-3.5 text-[#c9ff51]" />
              내 위치 핀 미세 이동 (상/하/좌/우)
            </span>
            <span className="text-[10px] text-slate-400">실내 위치 조정</span>
          </div>

          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 flex flex-col items-center gap-2">
            {/* North */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onMicroMove(STEP_5M, 0)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                ▲ 북쪽 +5m
              </button>
              <button
                type="button"
                onClick={() => onMicroMove(STEP_1M, 0)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-[#c9ff51] rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                ▲ +1m
              </button>
            </div>

            {/* West & East */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onMicroMove(0, -STEP_5M)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                ◀ 서쪽 -5m
              </button>
              <button
                type="button"
                onClick={() => onMicroMove(0, -STEP_1M)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-[#c9ff51] rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                ◀ -1m
              </button>

              <div className="w-7 h-7 rounded-full bg-[#c9ff51]/20 border border-[#c9ff51] flex items-center justify-center text-[10px] font-black text-[#c9ff51]">
                내위치
              </div>

              <button
                type="button"
                onClick={() => onMicroMove(0, STEP_1M)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-[#c9ff51] rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                +1m ▶
              </button>
              <button
                type="button"
                onClick={() => onMicroMove(0, STEP_5M)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                동쪽 +5m ▶
              </button>
            </div>

            {/* South */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onMicroMove(-STEP_1M, 0)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-[#c9ff51] rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                ▼ -1m
              </button>
              <button
                type="button"
                onClick={() => onMicroMove(-STEP_5M, 0)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                ▼ 남쪽 -5m
              </button>
            </div>
          </div>
        </div>

        {/* 2. Compass Heading Angle Offset */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1">
              <Compass className="w-3.5 h-3.5 text-[#c9ff51]" />
              AR 화살표 / 나침반 방향 회전 보정
            </span>
            <span className="text-[11px] font-mono font-bold text-[#c9ff51]">
              {headingOffset > 0 ? `+${headingOffset}°` : `${headingOffset}°`}
            </span>
          </div>

          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between gap-1">
              <button
                type="button"
                onClick={() => onHeadingOffsetChange(headingOffset - 45)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl text-slate-200 border border-slate-700 active:scale-95"
              >
                ↺ -45°
              </button>
              <button
                type="button"
                onClick={() => onHeadingOffsetChange(headingOffset - 15)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl text-[#c9ff51] border border-slate-700 active:scale-95"
              >
                ↺ -15°
              </button>
              <button
                type="button"
                onClick={() => onHeadingOffsetChange(0)}
                className="px-3 py-2 bg-slate-700 hover:bg-slate-600 text-xs font-bold rounded-xl text-white border border-slate-600 active:scale-95"
              >
                원래대로
              </button>
              <button
                type="button"
                onClick={() => onHeadingOffsetChange(headingOffset + 15)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl text-[#c9ff51] border border-slate-700 active:scale-95"
              >
                ↻ +15°
              </button>
              <button
                type="button"
                onClick={() => onHeadingOffsetChange(headingOffset + 45)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl text-slate-200 border border-slate-700 active:scale-95"
              >
                ↻ +45°
              </button>
            </div>
          </div>
        </div>

        {/* 3. Indoor Direct Distance Preset */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-[#c9ff51]" />
              실내 2인 일행 테스트용 거리 고정 모드
            </span>
            <span className="text-[10px] text-slate-400">
              {overrideDistance ? `${overrideDistance}m 고정` : '자동 GPS 거리'}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {[null, 3, 5, 10].map((val) => (
              <button
                key={val === null ? 'auto' : val}
                type="button"
                onClick={() => onSetOverrideDistance(val)}
                className={`py-2.5 rounded-xl text-xs font-bold transition-all border flex items-center justify-center gap-1 ${
                  overrideDistance === val
                    ? 'bg-[#c9ff51] text-[#111a35] border-[#c9ff51] shadow-lg'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                {val === null ? '자동 (GPS)' : `${val}m 고정`}
              </button>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex items-center gap-2">
          <button
            type="button"
            onClick={onResetCalibration}
            className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-2xl border border-slate-700 transition-all flex items-center justify-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>보정 초기화</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 bg-[#c9ff51] hover:bg-[#b5f03a] text-[#111a35] font-black text-xs rounded-2xl transition-all shadow-lg shadow-[#c9ff51]/10 flex items-center justify-center gap-1"
          >
            <Check className="w-4 h-4" />
            <span>보정 완료 적용</span>
          </button>
        </div>
      </div>
    </div>
  );
};
