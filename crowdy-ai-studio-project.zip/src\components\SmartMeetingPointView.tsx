import React, { useState } from 'react';
import { Friend, UserLocation } from '../types';
import { getDistanceInMeters } from '../utils/geoUtils';
import { ChevronLeft, Home, Sparkles, Check, MapPin, Award } from 'lucide-react';

interface SmartMeetingPointViewProps {
  userLocation: UserLocation;
  activeFriend: Friend | null;
  onClose: () => void;
}

export const SmartMeetingPointView: React.FC<SmartMeetingPointViewProps> = ({
  userLocation,
  activeFriend,
  onClose,
}) => {
  const [confirmed, setConfirmed] = useState(false);

  const friendDistance = activeFriend
    ? getDistanceInMeters(userLocation, activeFriend.location)
    : 120;

  const userEstMinutes = Math.max(1, Math.round(friendDistance / 120));
  const friendEstMinutes = Math.max(1, Math.round(friendDistance / 110));

  const meetingSpots = [
    {
      id: 'spot-1',
      title: '일행 간 최적 중간 지점 (추천)',
      score: 98,
      category: '중간 계산 지점',
      timeText: `나에게서 약 ${userEstMinutes}분 · ${activeFriend?.name || '일행'}에게서 약 ${friendEstMinutes}분`,
      desc: '두 사람의 실시간 GPS 중간 위치를 계산하여 가장 동등하게 접근 가능한 장소입니다.',
      recommended: true,
    },
    {
      id: 'spot-2',
      title: '주요 출입구 / 안내 센터',
      score: 92,
      category: '식별 용이 랜드마크',
      timeText: '멀리서도 시야에 잘 띄는 주요 안내소 근처',
      desc: '시야 확보가 용이하고 조명이 밝아 첫 합류 장소로 적합합니다.',
      recommended: false,
    },
    {
      id: 'spot-3',
      title: '중앙 대기 쉼터 / 휴게 구역',
      score: 87,
      category: '편의 쉼터',
      timeText: '중앙 이동 통로 근처',
      desc: '앉아서 대기할 수 있어 일행이 서로를 기다리기 편한 위치입니다.',
      recommended: false,
    },
  ];

  const [selectedSpotId, setSelectedSpotId] = useState('spot-1');
  const selectedSpot = meetingSpots.find((s) => s.id === selectedSpotId) || meetingSpots[0];

  const handleConfirm = () => {
    setConfirmed(true);
    setTimeout(() => setConfirmed(false), 3000);
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-gradient-to-b from-[#f8f7ff] to-white text-[#17213b] p-5 overflow-y-auto z-20">
      {/* Back Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-100 shrink-0">
        <button
          onClick={onClose}
          className="text-xs font-bold text-[#7054db] flex items-center gap-1 hover:underline"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>지도 화면으로</span>
        </button>
        <span className="text-[10px] bg-[#f0edff] text-[#7054db] font-bold px-2.5 py-1 rounded-full flex items-center gap-1">
          <Sparkles className="w-3 h-3" />
          스마트 중간 지점 AI
        </span>
      </div>

      {/* Main Content Title */}
      <div className="mt-4 mb-5">
        <p className="text-[11px] font-extrabold text-[#7054db] uppercase tracking-wider">
          SMART MEETING POINT
        </p>
        <h1 className="text-2xl font-black leading-tight text-[#111a35] mt-1">
          모두에게 가장<br />
          가까운 랜드마크에요.
        </h1>
      </div>

      {/* Selected Recommended Spot Card */}
      <div className="bg-[#111a35] text-white p-5 rounded-3xl shadow-xl space-y-3 relative overflow-hidden">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#c9ff51] text-[#111a35] flex items-center justify-center font-black text-2xl shadow-md shrink-0">
              <Home className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] text-[#c9ff51] font-bold tracking-wide">
                AI 추천 1위 만남 장소
              </span>
              <h2 className="text-lg font-black leading-snug">{selectedSpot.title}</h2>
              <p className="text-xs text-slate-300 mt-0.5">{selectedSpot.timeText}</p>
            </div>
          </div>
          <span className="text-lg font-black text-[#c9ff51] bg-white/10 px-2.5 py-1 rounded-xl">
            {selectedSpot.score}점
          </span>
        </div>

        <div className="pt-2 border-t border-slate-700/60 text-xs text-slate-300">
          <p>{selectedSpot.desc}</p>
        </div>
      </div>

      {/* Reason Box */}
      <div className="mt-4 p-4 rounded-2xl bg-[#f0edff] text-xs text-slate-600 space-y-1">
        <p className="font-extrabold text-[#7054db] flex items-center gap-1">
          <Award className="w-4 h-4" />
          추천 알고리즘 기준
        </p>
        <p>
          현재 위치와 상대방({activeFriend ? activeFriend.name : '일행'}) 위치의 기하학적 중간 지점을 계산하여, 혼잡도가 적고 조명이 밝은 공식 랜드마크를 우선 선택했습니다.
        </p>
      </div>

      {/* Spot Selector List */}
      <div className="mt-5 space-y-2.5">
        <p className="text-xs font-bold text-slate-500">다른 후보 장소 선택</p>
        {meetingSpots.map((spot) => (
          <button
            key={spot.id}
            onClick={() => setSelectedSpotId(spot.id)}
            className={`w-full p-3.5 rounded-2xl text-left border transition-all flex items-center justify-between ${
              selectedSpotId === spot.id
                ? 'border-[#7054db] bg-white shadow-md ring-2 ring-[#7054db]/20'
                : 'border-slate-100 bg-slate-50/80 hover:bg-white'
            }`}
          >
            <div className="flex items-center gap-3">
              <MapPin className={`w-5 h-5 ${selectedSpotId === spot.id ? 'text-[#7054db]' : 'text-slate-400'}`} />
              <div>
                <h3 className="text-xs font-bold text-slate-800">{spot.title}</h3>
                <p className="text-[10px] text-slate-500">{spot.category}</p>
              </div>
            </div>
            <span className="text-xs font-bold text-slate-600">{spot.score}점</span>
          </button>
        ))}
      </div>

      {/* Confirm Button */}
      <div className="mt-6 pt-2">
        <button
          onClick={handleConfirm}
          className={`w-full py-4 rounded-2xl font-black text-sm transition-all shadow-lg flex items-center justify-center gap-2 ${
            confirmed
              ? 'bg-emerald-500 text-white'
              : 'bg-[#c9ff51] text-[#111a35] hover:bg-[#b8f533]'
          }`}
        >
          {confirmed ? (
            <>
              <Check className="w-5 h-5" />
              <span>✓ 선택한 장소가 일행에게 공유되었어요!</span>
            </>
          ) : (
            <span>여기로 만남 장소 공유하기</span>
          )}
        </button>
      </div>
    </div>
  );
};
