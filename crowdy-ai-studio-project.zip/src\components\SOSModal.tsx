import React, { useState } from 'react';
import { UserLocation, Friend } from '../types';
import { AlertTriangle, Send, X, ShieldAlert, Check } from 'lucide-react';

interface SOSModalProps {
  isOpen: boolean;
  userLocation: UserLocation;
  allFriends: Friend[];
  onClose: () => void;
}

export const SOSModal: React.FC<SOSModalProps> = ({
  isOpen,
  userLocation,
  allFriends,
  onClose,
}) => {
  const [sent, setSent] = useState(false);

  if (!isOpen) return null;

  const handleSendSos = () => {
    setSent(true);
    setTimeout(() => {
      setSent(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-5 bg-[#10182ce8] backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-sm bg-white rounded-3xl p-6 text-center shadow-2xl space-y-4 border border-rose-100">
        <div className="w-14 h-14 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-2xl font-bold shadow-inner animate-pulse">
          <AlertTriangle className="w-8 h-8 text-rose-600" />
        </div>

        <div>
          <p className="text-xs font-bold text-rose-600 tracking-wider uppercase">EMERGENCY SOS</p>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">긴급 위치 알림을 보낼까요?</h2>
          <p className="text-xs text-slate-500 mt-1">
            등록된 모든 일행({allFriends.length}명)에게 내 실시간 GPS 좌표와 긴급 비상 신호가 즉시 전송됩니다.
          </p>
        </div>

        <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-[11px] font-mono text-slate-600 space-y-0.5">
          <p className="font-bold text-slate-800">현재 내 GPS 좌표</p>
          <p className="text-rose-600 font-bold">
            위도: {userLocation.lat.toFixed(5)}, 경도: {userLocation.lng.toFixed(5)}
          </p>
          <p className="text-[10px] text-slate-400">정확도 ±{Math.round(userLocation.accuracy || 15)}m</p>
        </div>

        {sent ? (
          <div className="p-4 bg-rose-600 text-white font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 shadow-lg animate-bounce">
            <Check className="w-5 h-5" />
            <span>긴급 SOS 신호가 일행에게 전송되었습니다!</span>
          </div>
        ) : (
          <div className="space-y-2 pt-1">
            <button
              onClick={handleSendSos}
              className="w-full bg-rose-600 hover:bg-rose-700 text-white font-extrabold py-3.5 rounded-2xl text-xs shadow-lg shadow-rose-600/30 transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>SOS 비상 신호 보내기</span>
            </button>
            <button
              onClick={onClose}
              className="w-full bg-transparent hover:bg-slate-100 text-slate-500 font-bold py-2.5 rounded-2xl text-xs transition-colors"
            >
              취소
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
