import React, { useState } from 'react';
import { UserProfile, Friend } from '../types';
import { X, UserPlus, Copy, Check, UserCheck, ShieldCheck, Battery, MapPin, Search, Sparkles } from 'lucide-react';

interface AuthAndFriendsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  friends: Friend[];
  activeFriend: Friend | null;
  onLogin: (name: string, email: string) => void;
  onAddFriendByCode: (code: string) => boolean;
  onSelectActiveFriend: (friend: Friend) => void;
  onLogout?: () => void;
}

export const AuthAndFriendsModal: React.FC<AuthAndFriendsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  friends,
  activeFriend,
  onLogin,
  onAddFriendByCode,
  onSelectActiveFriend,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'friends' | 'login' | 'add'>('friends');
  const [loginName, setLoginName] = useState(currentUser.name || '');
  const [loginEmail, setLoginEmail] = useState(currentUser.email || '');
  const [friendCodeInput, setFriendCodeInput] = useState('');
  const [addSuccessMessage, setAddSuccessMessage] = useState('');
  const [addErrorMessage, setAddErrorMessage] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginName.trim()) return;
    onLogin(loginName.trim(), loginEmail.trim());
    setActiveTab('friends');
  };

  const handleAddFriendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAddErrorMessage('');
    setAddSuccessMessage('');
    
    if (!friendCodeInput.trim()) {
      setAddErrorMessage('친구 코드를 입력해 주세요.');
      return;
    }

    const success = onAddFriendByCode(friendCodeInput.trim());
    if (success) {
      setAddSuccessMessage('친구를 성공적으로 추가했습니다!');
      setFriendCodeInput('');
      setTimeout(() => {
        setAddSuccessMessage('');
        setActiveTab('friends');
      }, 1200);
    } else {
      setAddErrorMessage('존재하지 않거나 이미 추가된 친구 코드입니다.');
    }
  };

  const copyMyCode = () => {
    navigator.clipboard.writeText(currentUser.userCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#10182c]/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#7054db] text-white flex items-center justify-center font-bold text-sm shadow-sm">
              ✦
            </div>
            <div>
              <h2 className="text-base font-bold text-[#111a35]">일행 및 계정 관리</h2>
              <p className="text-xs text-slate-500">친구를 추가하고 AR로 찾을 상대를 선택하세요</p>
            </div>
          </div>
          <button
            id="close-auth-modal-btn"
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-200 text-slate-500 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 border-b border-slate-100 bg-slate-100/50 p-1 gap-1">
          <button
            id="tab-friends-list"
            onClick={() => setActiveTab('friends')}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'friends'
                ? 'bg-white text-[#7054db] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            내 일행 ({friends.length})
          </button>
          <button
            id="tab-add-friend"
            onClick={() => setActiveTab('add')}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'add'
                ? 'bg-white text-[#7054db] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            + 친구 추가
          </button>
          <button
            id="tab-user-profile"
            onClick={() => setActiveTab('login')}
            className={`py-2 text-xs font-bold rounded-xl transition-all ${
              activeTab === 'login'
                ? 'bg-white text-[#7054db] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            내 프로필
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* TAB 1: FRIENDS LIST */}
          {activeTab === 'friends' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                <span>현재 추적할 일행을 선택하세요</span>
                <span className="text-[10px] bg-[#eaffd6] text-[#3c5e0d] px-2 py-0.5 rounded-full font-bold">
                  실시간 연동 중
                </span>
              </div>

              {friends.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <UserPlus className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-bold text-slate-700">등록된 일행이 없습니다</p>
                  <p className="text-xs text-slate-400 mt-1">친구 추가 탭에서 친구 코드를 입력해 보세요</p>
                  <button
                    onClick={() => setActiveTab('add')}
                    className="mt-4 bg-[#7054db] text-white text-xs font-bold px-4 py-2 rounded-xl"
                  >
                    친구 코드 입력하기
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {friends.map((friend) => {
                    const isSelected = activeFriend?.id === friend.id;
                    return (
                      <div
                        key={friend.id}
                        className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                          isSelected
                            ? 'border-[#7054db] bg-[#f0edff]/40 shadow-sm ring-2 ring-[#7054db]/20'
                            : 'border-slate-100 hover:border-slate-200 bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="w-11 h-11 rounded-2xl flex items-center justify-center font-extrabold text-slate-800 text-sm shadow-sm relative shrink-0"
                            style={{ backgroundColor: friend.avatarBg }}
                          >
                            {friend.avatarInitial}
                            <span
                              className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white ${
                                friend.isOnline ? 'bg-emerald-500' : 'bg-slate-300'
                              }`}
                            />
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-slate-900 text-sm">{friend.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">#{friend.code}</span>
                            </div>
                            <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                              {friend.statusMessage || '위치 공유 중'}
                            </p>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                              <span className="flex items-center gap-0.5">
                                <Battery className="w-3 h-3 text-emerald-600" />
                                {friend.battery}%
                              </span>
                              <span>•</span>
                              <span className="flex items-center gap-0.5">
                                <MapPin className="w-3 h-3 text-[#7054db]" />
                                GPS 온라인
                              </span>
                            </div>
                          </div>
                        </div>

                        <button
                          id={`select-friend-${friend.id}`}
                          onClick={() => {
                            onSelectActiveFriend(friend);
                            onClose();
                          }}
                          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                            isSelected
                              ? 'bg-[#111a35] text-white shadow-sm'
                              : 'bg-slate-100 text-slate-700 hover:bg-[#c9ff51] hover:text-[#111a35]'
                          }`}
                        >
                          {isSelected ? '추적 중 ✓' : 'AR로 찾기'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ADD FRIEND */}
          {activeTab === 'add' && (
            <div className="space-y-5">
              {/* My Friend Code Banner */}
              <div className="bg-[#111a35] text-white p-4 rounded-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-3 opacity-10">
                  <Sparkles className="w-20 h-20 text-[#c9ff51]" />
                </div>
                <p className="text-[11px] text-slate-300 font-medium">내 친구 고유 코드</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-xl font-black font-mono tracking-wider text-[#c9ff51]">
                    #{currentUser.userCode}
                  </span>
                  <button
                    onClick={copyMyCode}
                    className="flex items-center gap-1 text-xs bg-white/10 hover:bg-white/20 text-white font-bold px-3 py-1.5 rounded-xl transition-all"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? '복사됨' : '코드 복사'}</span>
                  </button>
                </div>
              </div>

              {/* Add Friend Form */}
              <form onSubmit={handleAddFriendSubmit} className="space-y-3">
                <label className="block text-xs font-bold text-slate-700">
                  친구 코드 또는 이메일로 추가하기
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={friendCodeInput}
                    onChange={(e) => setFriendCodeInput(e.target.value)}
                    placeholder="예: MINJI99 또는 DOYUN26"
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#7054db] focus:bg-white"
                  />
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                </div>

                {addErrorMessage && (
                  <p className="text-xs text-rose-500 font-bold">{addErrorMessage}</p>
                )}
                {addSuccessMessage && (
                  <p className="text-xs text-emerald-600 font-bold">{addSuccessMessage}</p>
                )}

                <button
                  type="submit"
                  id="submit-add-friend-btn"
                  className="w-full bg-[#7054db] text-white font-bold py-3 rounded-2xl text-xs shadow-md hover:bg-[#5b42be] transition-all flex items-center justify-center gap-1.5"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>친구 요청 전송 및 등록</span>
                </button>
              </form>

              {/* Preset Quick Add Helpers */}
              <div className="pt-2 border-t border-slate-100">
                <p className="text-[11px] text-slate-400 font-bold mb-2">빠른 테스트 일행 코드</p>
                <div className="flex flex-wrap gap-2">
                  {['MINJI99', 'DOYUN26', 'SEO0712'].map((code) => (
                    <button
                      key={code}
                      onClick={() => setFriendCodeInput(code)}
                      className="text-xs bg-slate-100 hover:bg-[#f0edff] hover:text-[#7054db] px-2.5 py-1 rounded-lg text-slate-600 font-mono transition-colors"
                    >
                      +{code}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: USER PROFILE / LOGIN */}
          {activeTab === 'login' && (
            <div className="space-y-4">
              <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center font-extrabold text-slate-900 text-xl shadow-sm"
                  style={{ backgroundColor: currentUser.avatarBg }}
                >
                  {currentUser.avatarInitial}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">{currentUser.name}</h3>
                  <p className="text-xs text-slate-500">{currentUser.email || '익명 로그인 사용자'}</p>
                  <span className="inline-block mt-1 text-[10px] bg-[#c9ff51] text-[#283808] font-black px-2 py-0.5 rounded-full">
                    코드: #{currentUser.userCode}
                  </span>
                </div>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    프로필 닉네임 수정
                  </label>
                  <input
                    type="text"
                    value={loginName}
                    onChange={(e) => setLoginName(e.target.value)}
                    required
                    placeholder="닉네임 입력 (예: 재훈)"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#7054db] focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    이메일 주소 (선택)
                  </label>
                  <input
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#7054db] focus:bg-white"
                  />
                </div>

                <button
                  type="submit"
                  id="save-profile-btn"
                  className="w-full bg-[#111a35] text-white font-bold py-3 rounded-2xl text-xs shadow-md hover:bg-slate-800 transition-all flex items-center justify-center gap-1.5 mt-2"
                >
                  <ShieldCheck className="w-4 h-4 text-[#c9ff51]" />
                  <span>프로필 정보 저장</span>
                </button>

                {onLogout && (
                  <button
                    type="button"
                    onClick={() => {
                      onLogout();
                      onClose();
                    }}
                    className="w-full bg-rose-50 text-rose-600 font-bold py-2.5 rounded-2xl text-xs hover:bg-rose-100 transition-all text-center mt-2"
                  >
                    로그아웃 및 그룹 재설정
                  </button>
                )}
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
