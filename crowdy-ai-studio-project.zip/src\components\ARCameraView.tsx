import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { UserLocation, Friend } from '../types';
import { getDistanceInMeters, getBearing, formatDistance } from '../utils/geoUtils';
import { ChevronLeft, Camera, Compass, MapPin, RefreshCw, AlertCircle, Building2 } from 'lucide-react';

interface ARCameraViewProps {
  userLocation: UserLocation;
  activeFriend: Friend | null;
  onClose: () => void;
  headingOffset?: number;
  overrideDistance?: number | null;
  onOpenIndoorCalibration?: () => void;
}

export const ARCameraView: React.FC<ARCameraViewProps> = ({
  userLocation,
  activeFriend,
  onClose,
  headingOffset = 0,
  overrideDistance,
  onOpenIndoorCalibration,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string>('');
  const [heading, setHeading] = useState<number>(0);

  // Calculate distance and bearing to active friend
  const realDistance = activeFriend
    ? getDistanceInMeters(userLocation, activeFriend.location)
    : 85;

  const distance = overrideDistance !== null && overrideDistance !== undefined ? overrideDistance : realDistance;

  const targetBearing = activeFriend
    ? getBearing(userLocation, activeFriend.location)
    : 45;

  const effectiveHeading = (heading + headingOffset + 360) % 360;

  // Relative turn angle for 3D arrow
  const turnAngle = (targetBearing - effectiveHeading + 360) % 360;

  // 1. Initialize Camera Video Stream
  useEffect(() => {
    let stream: MediaStream | null = null;

    async function setupCamera() {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('카메라 API를 지원하지 않는 브라우저입니다.');
        }

        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setCameraActive(true);
        }
      } catch (err: any) {
        console.warn('Camera stream error, fallback to AR background canvas:', err);
        setCameraError('카메라 권한을 요청 중이거나 가상 스튜디오 모드가 활성화되었습니다.');
      }
    }

    setupCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // 2. Listen to Device Orientation Sensor for Compass Heading
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      let currentHeading = 0;
      if ((e as any).webkitCompassHeading !== undefined) {
        currentHeading = (e as any).webkitCompassHeading;
      } else if (e.alpha !== null) {
        currentHeading = 360 - e.alpha;
      }
      setHeading(currentHeading);
    };

    window.addEventListener('deviceorientation', handleOrientation, true);
    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, []);

  // 3. Initialize Three.js 3D AR Engine (Renders 3D Floating Blue Chevron Arrows)
  useEffect(() => {
    if (!canvasRef.current) return;

    const width = canvasRef.current.clientWidth || window.innerWidth;
    const height = canvasRef.current.clientHeight || 400;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 1.2, 3);
    camera.lookAt(0, 0, -2);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      alpha: true,
      antialias: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(5, 10, 7);
    scene.add(dirLight);

    // Group for 3D Chevron Arrow Path
    const arrowGroup = new THREE.Group();
    scene.add(arrowGroup);

    // Create 3D Blue Chevron Arrow Geometries matching the photo design!
    const createChevronMesh = (zOffset: number) => {
      const shape = new THREE.Shape();
      // Outer arrow chevron shape
      shape.moveTo(0, 0.9);
      shape.lineTo(0.7, 0);
      shape.lineTo(0.4, 0);
      shape.lineTo(0, 0.5);
      shape.lineTo(-0.4, 0);
      shape.lineTo(-0.7, 0);
      shape.closePath();

      const extrudeSettings = {
        steps: 1,
        depth: 0.25,
        bevelEnabled: true,
        bevelThickness: 0.05,
        bevelSize: 0.05,
        bevelSegments: 3,
      };

      const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
      // Bright vibrant blue material matching user's reference photo!
      const material = new THREE.MeshStandardMaterial({
        color: 0x0088ff,
        metalness: 0.2,
        roughness: 0.3,
        emissive: 0x0044aa,
        emissiveIntensity: 0.3,
      });

      const mesh = new THREE.Mesh(geometry, material);
      mesh.rotation.x = -Math.PI / 4; // Tilted on floor
      mesh.position.set(0, 0, zOffset);
      return mesh;
    };

    // Add 2 floating 3D chevron arrows along the direction path
    const arrow1 = createChevronMesh(-1.2);
    const arrow2 = createChevronMesh(-2.4);
    arrowGroup.add(arrow1);
    arrowGroup.add(arrow2);

    // Animation loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();

      // Subtle floating and pulse effect
      arrow1.position.y = Math.sin(elapsedTime * 3) * 0.08;
      arrow2.position.y = Math.sin(elapsedTime * 3 + 0.8) * 0.08;

      // Rotate group towards relative target bearing
      const rad = (turnAngle * Math.PI) / 180;
      arrowGroup.rotation.y = THREE.MathUtils.lerp(arrowGroup.rotation.y, -rad, 0.1);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!canvasRef.current) return;
      const w = canvasRef.current.clientWidth;
      const h = canvasRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [turnAngle]);

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-950 text-white overflow-hidden z-30">
      {/* Top Camera Stream View (65% height) */}
      <div className="relative w-full flex-1 overflow-hidden">
        {/* Background Video element */}
        <video
          ref={videoRef}
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
            cameraActive ? 'opacity-100' : 'opacity-20'
          }`}
        />

        {/* Fallback Indoor Mall / Festival AR Scene Background when camera stream is off */}
        {!cameraActive && (
          <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-800 to-amber-950/40 flex items-center justify-center">
            <div className="text-center p-6 text-slate-300">
              <Camera className="w-10 h-10 mx-auto text-[#c9ff51] mb-2 animate-bounce" />
              <p className="text-xs font-bold">실시간 AR 카메라 모드</p>
              <p className="text-[10px] text-slate-400 mt-1">
                카메라 화면에 3D 길 안내 입체 화살표가 오버레이됩니다
              </p>
            </div>
          </div>
        )}

        {/* Three.js 3D WebGL Overlay Canvas */}
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none z-10" />

        {/* Top AR Navigation Bar */}
        <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between">
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-slate-900/70 backdrop-blur-md text-white flex items-center justify-center border border-white/20 active:scale-95 transition-transform"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Compass Strip */}
          <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full text-xs font-mono font-bold tracking-widest text-slate-300 border border-white/10 flex items-center gap-1.5">
            <span className="text-[#c9ff51] font-sans text-[10px]">{Math.round(effectiveHeading)}°</span>
            <span className="text-slate-500">|</span>
            <Compass className="w-3.5 h-3.5 text-[#c9ff51] animate-spin" style={{ animationDuration: '10s' }} />
          </div>

          {onOpenIndoorCalibration && (
            <button
              onClick={onOpenIndoorCalibration}
              className="px-3 py-2 rounded-full bg-[#7054db]/90 backdrop-blur-md text-[#c9ff51] text-xs font-bold border border-white/20 flex items-center gap-1.5 shadow-lg active:scale-95"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>실내 보정</span>
            </button>
          )}
        </div>

        {/* Center Target Info Overlay */}
        <div className="absolute bottom-6 left-0 right-0 z-20 text-center pointer-events-none drop-shadow-lg">
          <p className="text-xs font-bold text-slate-200 tracking-wide">
            {activeFriend ? `${activeFriend.name}님은 이쪽이에요` : '일행을 향해 전진하세요'}
          </p>
          <div className="text-5xl font-black text-white my-1 font-mono tracking-tight text-shadow-lg">
            {formatDistance(distance)}
          </div>
          <p className="text-[11px] text-slate-300 bg-slate-900/60 inline-block px-3 py-1 rounded-full backdrop-blur-sm border border-white/10">
            화살표 방향으로 직진하세요 (상대 위치 {Math.round(turnAngle)}°)
          </p>
        </div>
      </div>

      {/* Bottom Route Mini-Map Overlay (35% height) - EXACT MATCH to user's photo! */}
      <div className="h-48 w-full bg-slate-900 border-t-2 border-[#7054db] p-3 flex flex-col justify-between shrink-0 relative overflow-hidden z-20 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#0088ff] animate-ping" />
            <span className="text-xs font-extrabold text-white">실시간 도보 보행 미니맵</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            {activeFriend ? `목적지: ${activeFriend.name}` : '위치 추적 중'}
          </span>
        </div>

        {/* Indoor/Outdoor Map Vector Line graphic preview matching photo */}
        <div className="relative flex-1 my-2 bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
          <svg className="w-full h-full p-2" viewBox="0 0 300 100">
            {/* Grid background lines */}
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1e293b" strokeWidth="0.5" />
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid)" />

            {/* Path line from current pos to friend */}
            <path
              d="M 40,75 L 140,75 L 140,25 L 260,25"
              fill="none"
              stroke="#0088ff"
              strokeWidth="6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M 40,75 L 140,75 L 140,25 L 260,25"
              fill="none"
              stroke="#c9ff51"
              strokeWidth="2"
              strokeDasharray="4,4"
            />

            {/* User Pin */}
            <circle cx="40" cy="75" r="7" fill="#0088ff" stroke="#ffffff" strokeWidth="2" />
            <text x="40" y="93" fill="#ffffff" fontSize="9" fontWeight="bold" textAnchor="middle">
              내 위치
            </text>

            {/* Turning Point Marker */}
            <path d="M 130,75 L 140,75 L 140,65" fill="none" stroke="#ffffff" strokeWidth="2" />

            {/* Friend Pin */}
            <circle cx="260" cy="25" r="7" fill="#7054db" stroke="#c9ff51" strokeWidth="2" />
            <text x="260" y="42" fill="#c9ff51" fontSize="9" fontWeight="bold" textAnchor="middle">
              {activeFriend ? activeFriend.name : '일행'}
            </text>
          </svg>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1 text-slate-300">
            <MapPin className="w-3.5 h-3.5 text-[#0088ff]" />
            주변 안내: 중앙 매장 / 통로 안내소 직진 후 우회전
          </span>
          <button
            onClick={onClose}
            className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1 rounded-lg font-bold"
          >
            지도 뷰로 돌아가기
          </button>
        </div>
      </div>
    </div>
  );
};
