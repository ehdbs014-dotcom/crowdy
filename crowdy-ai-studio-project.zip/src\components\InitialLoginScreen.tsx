import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Sparkles, Users, Radio, ArrowRight, ShieldCheck, Smartphone } from 'lucide-react';

interface InitialLoginScreenProps {
  onStart: (name: string, groupCode: string, avatarBg: string) => void;
}

const COLOR_PRESETS = [
  '#c9ff51', // Neon Lime
  '#7054db', // Purple
  '#ffae92', // Peach
  '#a0e7e5', // Mint
  '#f04e62', // Rose
  '#ffd166', // Yellow
];

export const InitialLoginScreen: React.FC<InitialLoginScreenProps> = ({ onStart }) => {
  const [name, setName] = useState('');
  const [groupCode, setGroupCode] = useState('HOME');
  const [selectedColor, setSelectedColor] = useState(COLOR_PRESETS[0]);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('닉네임을 입력해 주세요.');
      return;
    }
    if (!groupCode.trim()) {
      setError('그룹 코드를 입력해 주세요.');
      return;
    }
    setError('');
    onStart(name.trim(), groupCode.trim().toUpperCase().replace('#', ''), selectedColor);
  };

  const handleQuickPreset = (presetName: string, presetGroup: string) => {
    setName(presetName);
    setGroupCode(presetGroup);
    setError('');
  };

  return (
    <div className="w-full h-full bg-[#111a35] text-white flex flex-col justify-between p-6 overflow-y-auto animate-fade-in relative z-50">
      {/* Background Decorative Accents */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#7054db]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-0 w-48 h-48 bg-[#c9ff51]/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header & Brand */}
      <div className="pt-6 relative z-10">
        <div className="inline-flex items-center gap-1.5 bg-white/10 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-full text-xs font-bold text-[#c9ff51] mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Crowdy AR Companion Finder</span>
        </div>
        <h1 className="text-3xl font-black tracking-tight leading-tight">
          사람 많은 곳에서도,<br />
          <span className="text-[#c9ff51]">우리는 다시 만난다</span>
        </h1>
        <p className="text-xs text-slate-300 mt-2 font-medium leading-relaxed">
          실시간 위치 공유와 AR 3D 입체 화살표로<br />
          복잡한 현장과 복도에서도 일행을 쉽게 찾아보세요.
        </p>
      </div>

      {/* Login Form */}
      <form onSubmit={handleSubmit} className="my-6 space-y-4 relative z-10 bg-white/5 backdrop-blur-lg p-5 rounded-3xl border border-white/10 shadow-2xl">
        <div>
          <label className="block text-xs font-bold text-slate-200 mb-1.5">
            내 닉네임 (프로필 이름)
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="예: 재훈 또는 스마트폰 A"
            className="w-full px-4 py-3 bg-slate-900/80 border border-slate-700/80 rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#c9ff51] focus:border-transparent font-medium"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-200 mb-1.5">
            일행 그룹 코드 (동일 코드 입력 시 연결)
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-3.5 text-slate-500 font-mono text-sm">#</span>
            <input
              type="text"
              value={groupCode}
              onChange={(e) => setGroupCode(e.target.value)}
              placeholder="예: HOME 또는 GROUP1"
              className="w-full pl-8 pr-4 py-3 bg-slate-900/80 border border-slate-700/80 rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#c9ff51] focus:border-transparent font-mono uppercase font-bold"
            />
          </div>
          <p className="text-[10px] text-slate-400 mt-1">
            💡 휴대폰 2대에서 같은 그룹 코드를 입력하면 실시간으로 연동됩니다.
          </p>
        </div>

        {/* Color Accent Picker */}
        <div>
          <label className="block text-xs font-bold text-slate-200 mb-1.5">
            내 아이콘 컬러
          </label>
          <div className="flex items-center gap-2">
            {COLOR_PRESETS.map((color) => (
              <button
                key={color}
                type="button"
                onClick={() => setSelectedColor(color)}
                className={`w-8 h-8 rounded-full transition-all ${
                  selectedColor === color
                    ? 'ring-4 ring-white scale-110 shadow-lg'
                    : 'opacity-70 hover:opacity-100'
                }`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>

        {error && <p className="text-xs text-rose-400 font-bold">{error}</p>}

        {/* Start Button */}
        <button
          type="submit"
          id="login-start-btn"
          className="w-full py-4 rounded-2xl bg-[#c9ff51] hover:bg-[#b8f533] text-[#111a35] font-black text-sm transition-all shadow-lg shadow-[#c9ff51]/20 flex items-center justify-center gap-2 active:scale-95"
        >
          <span>Crowdy 시작하기</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </form>

      {/* Quick Test Presets for 2-Phone Testing */}
      <div className="relative z-10 pt-2 border-t border-white/10 space-y-2">
        <p className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
          <Smartphone className="w-3.5 h-3.5 text-[#c9ff51]" />
          휴대폰 2대 시험용 빠른 테스트 설정:
        </p>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => handleQuickPreset('스마트폰 1번', 'HOME')}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-xs font-bold transition-all text-slate-200 flex items-center justify-between"
          >
            <span>📱 폰 A (스마트폰 1)</span>
            <span className="text-[10px] text-[#c9ff51] font-mono">#HOME</span>
          </button>
          <button
            type="button"
            onClick={() => handleQuickPreset('스마트폰 2번', 'HOME')}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left text-xs font-bold transition-all text-slate-200 flex items-center justify-between"
          >
            <span>📱 폰 B (스마트폰 2)</span>
            <span className="text-[10px] text-[#c9ff51] font-mono">#HOME</span>
          </button>
        </div>
      </div>
    </div>
  );
};
