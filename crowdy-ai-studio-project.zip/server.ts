import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

interface UserLocationPayload {
  userId: string;
  userName: string;
  userCode: string;
  groupCode: string;
  lat: number;
  lng: number;
  heading?: number;
  battery?: number;
  statusMessage?: string;
  updatedAt: number;
}

// In-memory store for active locations grouped by groupCode
const groupLocationsStore: Record<string, Record<string, UserLocationPayload>> = {};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Heartbeat / Location update from phone
  app.post('/api/location/update', (req, res) => {
    const { userId, userName, userCode, groupCode, lat, lng, heading, battery, statusMessage } = req.body;

    if (!userId || !groupCode || lat === undefined || lng === undefined) {
      return res.status(400).json({ error: 'Missing required location fields' });
    }

    const cleanGroup = groupCode.trim().toUpperCase().replace('#', '');

    if (!groupLocationsStore[cleanGroup]) {
      groupLocationsStore[cleanGroup] = {};
    }

    groupLocationsStore[cleanGroup][userId] = {
      userId,
      userName: userName || '사용자',
      userCode: userCode || userId,
      groupCode: cleanGroup,
      lat: Number(lat),
      lng: Number(lng),
      heading: heading ? Number(heading) : 0,
      battery: battery ? Number(battery) : 100,
      statusMessage: statusMessage || '실시간 접속 중',
      updatedAt: Date.now(),
    };

    res.json({ status: 'ok', activeInGroup: Object.keys(groupLocationsStore[cleanGroup]).length });
  });

  // API Route: Get all live locations for a group
  app.get('/api/location/group/:groupCode', (req, res) => {
    const cleanGroup = req.params.groupCode.trim().toUpperCase().replace('#', '');
    const groupMembers = groupLocationsStore[cleanGroup] || {};

    const now = Date.now();
    const activeMembers: UserLocationPayload[] = [];

    // Filter members updated in the last 2 minutes
    Object.values(groupMembers).forEach((member) => {
      if (now - member.updatedAt < 120000) {
        activeMembers.push(member);
      }
    });

    res.json({
      groupCode: cleanGroup,
      members: activeMembers,
      count: activeMembers.length,
    });
  });

  const distPath = path.join(process.cwd(), 'dist');
  const distIndexExists = fs.existsSync(path.join(distPath, 'index.html'));

  if (process.env.NODE_ENV === 'production' && distIndexExists) {
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    // Vite middleware for development
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const indexPath = path.join(process.cwd(), 'index.html');
        let template = fs.readFileSync(indexPath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
