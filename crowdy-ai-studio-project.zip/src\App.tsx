import React, { useState, useEffect } from 'react';
import { UserProfile, Friend, UserLocation, ActiveTab } from './types';
import { getInitialDemoFriends } from './utils/geoUtils';
import { HeaderBar } from './components/HeaderBar';
import { LeafletMapView } from './components/LeafletMapView';
import { ARCameraView } from './components/ARCameraView';
import { SmartMeetingPointView } from './components/SmartMeetingPointView';
import { AuthAndFriendsModal } from './components/AuthAndFriendsModal';
import { SOSModal } from './components/SOSModal';
import { BottomNavBar } from './components/BottomNavBar';
import { InitialLoginScreen } from './components/InitialLoginScreen';
import { IndoorCalibrationModal } from './components/IndoorCalibrationModal';

export default function App() {
  // 1. User Profile State (Check localStorage or start logged-out)
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('crowdy_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      id: `user-${Date.now()}`,
      name: '',
      userCode: '',
      avatarBg: '#c9ff51',
      avatarInitial: '나',
      email: '',
      isLoggedIn: false,
    };
  });

  // Group Code
  const [groupCode, setGroupCode] = useState<string>(() => {
    return localStorage.getItem('crowdy_group') || 'HOME';
  });

  // 2. Location & GPS State
  const [userLocation, setUserLocation] = useState<UserLocation>({
    lat: 37.5665,
    lng: 126.9780,
    accuracy: 15,
  });
  const [isGpsLive, setIsGpsLive] = useState<boolean>(false);

  // 3. Friends & Active Companion State
  const [friends, setFriends] = useState<Friend[]>(() =>
    getInitialDemoFriends(37.5665, 126.9780)
  );
  const [activeFriend, setActiveFriend] = useState<Friend | null>(() => friends[0] || null);

  // 4. UI & Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('map');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isSosModalOpen, setIsSosModalOpen] = useState<boolean>(false);
  const [isIndoorModalOpen, setIsIndoorModalOpen] = useState<boolean>(false);
  const [headingOffset, setHeadingOffset] = useState<number>(0);
  const [overrideDistance, setOverrideDistance] = useState<number | null>(null);

  // Micro position fine-tuning handler for indoor calibration
  const handleMicroMove = (dLat: number, dLng: number) => {
    setUserLocation((prev) => ({
      ...prev,
      lat: prev.lat + dLat,
      lng: prev.lng + dLng,
      updatedAt: new Date().toISOString(),
    }));
  };

  const handleResetCalibration = () => {
    setHeadingOffset(0);
    setOverrideDistance(null);
  };

  // Live Real-Time Multi-Device Location Sync via Express Backend
  useEffect(() => {
    if (!currentUser || !userLocation) return;

    const syncLocation = async () => {
      try {
        // 1. Send my current live position to server
        await fetch('/api/location/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            userName: currentUser.name,
            userCode: currentUser.userCode,
            groupCode,
            lat: userLocation.lat,
            lng: userLocation.lng,
            heading: userLocation.heading || 0,
            battery: 90,
            statusMessage: '실시간 현장 접속 중',
          }),
        });

        // 2. Fetch all live members in the same group
        const res = await fetch(`/api/location/group/${groupCode}`);
        if (res.ok) {
          const data = await res.json();
          if (data.members && Array.isArray(data.members)) {
            // Convert other devices in group to friends list
            const realOtherDevices: Friend[] = data.members
              .filter((m: any) => m.userId !== currentUser.id)
              .map((m: any) => ({
                id: m.userId,
                name: m.userName,
                code: m.userCode,
                isOnline: true,
                avatarBg: '#c9ff51',
                avatarInitial: m.userName.slice(0, 1),
                location: {
                  lat: m.lat,
                  lng: m.lng,
                  heading: m.heading,
                },
                battery: m.battery || 85,
                statusMessage: '실시간 스마트폰 공유 중!',
              }));

            if (realOtherDevices.length > 0) {
              setFriends((prev) => {
                const demoOnly = prev.filter((f) => !f.id.startsWith('user-') && !f.id.startsWith('phone-'));
                return [...realOtherDevices, ...demoOnly];
              });
              // Auto set active friend to real connected phone if not set
              setActiveFriend((prev) => (prev && realOtherDevices.some((r) => r.id === prev.id) ? prev : realOtherDevices[0]));
            }
          }
        }
      } catch (err) {
        // Silent catch for dev server polling
      }
    };

    syncLocation();
    const interval = setInterval(syncLocation, 3000);
    return () => clearInterval(interval);
  }, [currentUser, userLocation, groupCode]);

  // Initialize Real GPS or Demo Simulation
  useEffect(() => {
    let watchId: number | null = null;

    // Immediately request current position on load
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const newLat = pos.coords.latitude;
          const newLng = pos.coords.longitude;

          setUserLocation({
            lat: newLat,
            lng: newLng,
            accuracy: pos.coords.accuracy || 10,
            updatedAt: new Date().toISOString(),
          });
          setIsGpsLive(true);
          const userFriends = getInitialDemoFriends(newLat, newLng);
          setFriends(userFriends);
          setActiveFriend(userFriends[0]);
        },
        (err) => {
          console.warn('Geolocation warning on startup:', err.message);
          setIsGpsLive(false);
        },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 5000 }
      );

      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const newLat = pos.coords.latitude;
          const newLng = pos.coords.longitude;

          setUserLocation({
            lat: newLat,
            lng: newLng,
            accuracy: pos.coords.accuracy || 10,
            heading: pos.coords.heading || 0,
            updatedAt: new Date().toISOString(),
          });
          setIsGpsLive(true);
        },
        (err) => {
          console.warn('Geolocation watch error:', err.message);
        },
        { enableHighAccuracy: true, maximumAge: 3000, timeout: 7000 }
      );
    }

    return () => {
      if (watchId !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  // Handler: Initial Login Start
  const handleInitialStart = (name: string, newGroupCode: string, avatarBg: string) => {
    const cleanCode = name.toUpperCase().replace(/\s+/g, '') + Math.floor(10 + Math.random() * 89);
    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      name,
      userCode: cleanCode,
      avatarBg: avatarBg || '#c9ff51',
      avatarInitial: name.slice(0, 1),
      email: `${name}@crowdy.app`,
      isLoggedIn: true,
    };
    setCurrentUser(newUser);
    setGroupCode(newGroupCode);
    localStorage.setItem('crowdy_user', JSON.stringify(newUser));
    localStorage.setItem('crowdy_group', newGroupCode);
  };

  // Handler: Logout
  const handleLogout = () => {
    localStorage.removeItem('crowdy_user');
    setCurrentUser({
      id: `user-${Date.now()}`,
      name: '',
      userCode: '',
      avatarBg: '#c9ff51',
      avatarInitial: '나',
      email: '',
      isLoggedIn: false,
    });
  };

  // Handler: Login / Update Profile
  const handleLogin = (name: string, email: string) => {
    const cleanCode = name.toUpperCase().replace(/\s+/g, '') + Math.floor(10 + Math.random() * 89);
    const updatedUser: UserProfile = {
      ...currentUser,
      name,
      userCode: cleanCode,
      email,
      isLoggedIn: true,
    };
    setCurrentUser(updatedUser);
    localStorage.setItem('crowdy_user', JSON.stringify(updatedUser));
  };

  // Handler: Add Friend By Code
  const handleAddFriendByCode = (code: string): boolean => {
    const cleanCode = code.trim().toUpperCase().replace('#', '');
    const existing = friends.find((f) => f.code === cleanCode);
    if (existing) return false;

    // Create new friend item
    const newFriend: Friend = {
      id: `f-${Date.now()}`,
      name: cleanCode.toLowerCase().startsWith('m') ? '민우' : '지은',
      code: cleanCode,
      isOnline: true,
      avatarBg: '#a0e7e5',
      avatarInitial: cleanCode.slice(0, 1),
      location: {
        lat: userLocation.lat + (Math.random() - 0.5) * 0.002,
        lng: userLocation.lng + (Math.random() - 0.5) * 0.002,
        accuracy: 15,
      },
      battery: Math.floor(Math.random() * 50) + 40,
      statusMessage: '방금 일행으로 등록되었어요',
    };

    setFriends((prev) => [...prev, newFriend]);
    setActiveFriend(newFriend);
    return true;
  };

  // Handler: Change Group Code
  const handleChangeGroupCode = () => {
    const input = prompt('새로운 그룹 코드 (#영문/숫자)를 입력하세요:', groupCode);
    if (input && input.trim()) {
      setGroupCode(input.trim().toUpperCase().replace('#', ''));
    }
  };

  // Handler: Toggle GPS & Relocate Festival Grounds to User's Real Current Location
  const handleToggleGps = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setUserLocation({
            lat,
            lng,
            accuracy: pos.coords.accuracy || 10,
          });
          setIsGpsLive(true);
          const newFriends = getInitialDemoFriends(lat, lng);
          setFriends(newFriends);
          setActiveFriend(newFriends[0]);
          alert(`축제 장소와 일행들이 현재 사용자의 실제 위치(${lat.toFixed(4)}, ${lng.toFixed(4)}) 주변으로 재배치되었습니다!`);
        },
        (err) => {
          alert('GPS 권한 요청 중 오류가 발생했거나 권한이 거부되었습니다. 브라우저 위치 권한을 허용해 주세요.');
        },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 8000 }
      );
    } else {
      alert('이 브라우저는 GPS 위치 기능을 지원하지 않습니다.');
    }
  };

  // Handler: Set custom location or preset city
  const handleSetCustomLocation = (lat: number, lng: number, label: string) => {
    setUserLocation({
      lat,
      lng,
      accuracy: 10,
      updatedAt: new Date().toISOString(),
    });
    setIsGpsLive(false);
    const newFriends = getInitialDemoFriends(lat, lng);
    setFriends(newFriends);
    setActiveFriend(newFriends[0]);
    alert(`축제 장소와 일행들이 [${label}] 주변으로 재배치되었습니다!`);
  };

  // Render Initial Login Screen if not logged in
  if (!currentUser.isLoggedIn) {
    return (
      <div className="w-full h-dvh max-w-md mx-auto bg-slate-900 flex flex-col overflow-hidden sm:rounded-[34px] sm:my-auto sm:h-[820px] sm:shadow-2xl sm:border-8 sm:border-slate-800 relative font-sans">
        <InitialLoginScreen onStart={handleInitialStart} />
      </div>
    );
  }

  return (
    <div className="w-full h-dvh max-w-md mx-auto bg-slate-900 flex flex-col overflow-hidden sm:rounded-[34px] sm:my-auto sm:h-[820px] sm:shadow-2xl sm:border-8 sm:border-slate-800 relative font-sans">
      {/* Top Header Bar */}
      <HeaderBar
        currentUser={currentUser}
        activeFriend={activeFriend}
        groupCode={groupCode}
        isGpsLive={isGpsLive}
        gpsAccuracy={userLocation.accuracy}
        userLat={userLocation.lat}
        userLng={userLocation.lng}
        onOpenAuthFriends={() => setIsAuthModalOpen(true)}
        onChangeGroupCode={handleChangeGroupCode}
        onToggleGps={handleToggleGps}
        onSetCustomLocation={handleSetCustomLocation}
        onOpenIndoorCalibration={() => setIsIndoorModalOpen(true)}
      />

      {/* Main View Area (Switches based on activeTab) */}
      <main className="relative flex-1 w-full h-full overflow-hidden flex flex-col">
        {activeTab === 'map' && (
          <LeafletMapView
            userLocation={userLocation}
            activeFriend={activeFriend}
            allFriends={friends}
            isGpsLive={isGpsLive}
            onOpenAr={() => setActiveTab('ar')}
            onSelectFriend={(friend) => setActiveFriend(friend)}
          />
        )}

        {activeTab === 'ar' && (
          <ARCameraView
            userLocation={userLocation}
            activeFriend={activeFriend}
            onClose={() => setActiveTab('map')}
            headingOffset={headingOffset}
            overrideDistance={overrideDistance}
            onOpenIndoorCalibration={() => setIsIndoorModalOpen(true)}
          />
        )}

        {activeTab === 'meet' && (
          <SmartMeetingPointView
            userLocation={userLocation}
            activeFriend={activeFriend}
            onClose={() => setActiveTab('map')}
          />
        )}
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        onOpenSos={() => setIsSosModalOpen(true)}
        onOpenFriends={() => setIsAuthModalOpen(true)}
      />

      {/* Auth & Friends Management Modal */}
      <AuthAndFriendsModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        friends={friends}
        activeFriend={activeFriend}
        onLogin={handleLogin}
        onAddFriendByCode={handleAddFriendByCode}
        onSelectActiveFriend={(friend) => setActiveFriend(friend)}
        onLogout={handleLogout}
      />

      {/* SOS Emergency Modal */}
      <SOSModal
        isOpen={isSosModalOpen}
        userLocation={userLocation}
        allFriends={friends}
        onClose={() => setIsSosModalOpen(false)}
      />

      {/* Indoor GPS & Sensor Calibration Modal */}
      <IndoorCalibrationModal
        isOpen={isIndoorModalOpen}
        onClose={() => setIsIndoorModalOpen(false)}
        gpsAccuracy={userLocation.accuracy}
        isGpsLive={isGpsLive}
        headingOffset={headingOffset}
        onHeadingOffsetChange={setHeadingOffset}
        onMicroMove={handleMicroMove}
        overrideDistance={overrideDistance}
        onSetOverrideDistance={setOverrideDistance}
        onResetCalibration={handleResetCalibration}
      />
    </div>
  );
}
