import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { UserLocation, Friend } from '../types';
import { getDistanceInMeters, formatDistance, getFestivalPlaces } from '../utils/geoUtils';
import { Navigation, Compass, MapPin, Sparkles } from 'lucide-react';

interface LeafletMapViewProps {
  userLocation: UserLocation;
  activeFriend: Friend | null;
  allFriends: Friend[];
  isGpsLive: boolean;
  onOpenAr: () => void;
  onSelectFriend: (friend: Friend) => void;
}

export const LeafletMapView: React.FC<LeafletMapViewProps> = ({
  userLocation,
  activeFriend,
  allFriends,
  isGpsLive,
  onOpenAr,
  onSelectFriend,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const polylineRef = useRef<L.Polyline | null>(null);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [userLocation.lat, userLocation.lng],
        zoom: 17,
        zoomControl: false,
        attributionControl: false,
      });

      // CartoDB Voyager clean tile layer
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update Markers and Polyline Route whenever locations change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Helper to create custom HTML marker icon for users/friends
    const createCustomIcon = (
      initial: string,
      name: string,
      bgColor: string,
      isUser: boolean = false
    ) => {
      const html = `
        <div class="flex flex-col items-center group cursor-pointer">
          <div class="w-9 h-9 rounded-full border-2 border-white shadow-lg flex items-center justify-center text-xs font-black text-slate-900 transition-transform transform group-hover:scale-110" style="background-color: ${bgColor}">
            ${initial}
          </div>
          <div class="mt-0.5 px-2 py-0.5 bg-white text-slate-800 text-[10px] font-extrabold rounded-md shadow-md border border-slate-100 whitespace-nowrap">
            ${name}
          </div>
        </div>
      `;
      return L.divIcon({
        html,
        className: 'custom-map-pin',
        iconSize: [40, 50],
        iconAnchor: [20, 45],
      });
    };

    // Helper to create festival landmark place icon
    const createPlaceIcon = (icon: string, title: string, category: string, bgColor: string, textColor: string) => {
      const html = `
        <div class="flex flex-col items-center group cursor-pointer">
          <div class="px-2.5 py-1 rounded-xl shadow-md border border-white flex items-center gap-1 text-[11px] font-black transition-transform transform group-hover:scale-110" style="background-color: ${bgColor}; color: ${textColor}">
            <span>${icon}</span>
            <span>${title}</span>
          </div>
          <div class="text-[9px] font-bold text-slate-500 bg-white/90 px-1.5 py-0.5 rounded shadow-sm border border-slate-100 mt-0.5">
            ${category}
          </div>
        </div>
      `;
      return L.divIcon({
        html,
        className: 'custom-place-pin',
        iconSize: [120, 45],
        iconAnchor: [60, 40],
      });
    };

    // 1. Update User Marker
    const userKey = 'user_me';
    if (!markersRef.current[userKey]) {
      const userMarker = L.marker([userLocation.lat, userLocation.lng], {
        icon: createCustomIcon('나', '내 위치', '#ffae92', true),
        zIndexOffset: 1000,
      }).addTo(map);
      markersRef.current[userKey] = userMarker;
    } else {
      markersRef.current[userKey].setLatLng([userLocation.lat, userLocation.lng]);
    }

    // 2. Update Friends Markers
    allFriends.forEach((friend) => {
      const friendKey = `friend_${friend.id}`;
      if (!markersRef.current[friendKey]) {
        const marker = L.marker([friend.location.lat, friend.location.lng], {
          icon: createCustomIcon(friend.avatarInitial, friend.name, friend.avatarBg),
        }).addTo(map);

        marker.on('click', () => onSelectFriend(friend));
        markersRef.current[friendKey] = marker;
      } else {
        markersRef.current[friendKey].setLatLng([friend.location.lat, friend.location.lng]);
      }
    });

    // 3. Draw Route Line between User and Active Friend
    if (activeFriend) {
      const latlngs: L.LatLngExpression[] = [
        [userLocation.lat, userLocation.lng],
        [activeFriend.location.lat, activeFriend.location.lng],
      ];

      if (!polylineRef.current) {
        polylineRef.current = L.polyline(latlngs, {
          color: '#7054db',
          weight: 5,
          opacity: 0.8,
          dashArray: '8, 8',
          lineCap: 'round',
        }).addTo(map);
      } else {
        polylineRef.current.setLatLngs(latlngs);
      }
    } else if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }
  }, [userLocation, activeFriend, allFriends]);


  const activeDistanceMeters = activeFriend
    ? getDistanceInMeters(userLocation, activeFriend.location)
    : null;

  return (
    <div className="relative w-full h-full flex-1 overflow-hidden bg-slate-100">
      {/* Map Element Container */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* Map Overlay Badges & Recenter Control */}
      <div className="absolute top-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <span className="bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-full text-[10px] font-bold text-slate-600 shadow-sm border border-slate-100 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-[#7054db]" />
          현재 상태: {isGpsLive ? '내 GPS 실시간 위치' : '위치 공유 시뮬레이션'}
        </span>

        <button
          onClick={() => {
            if (mapInstanceRef.current) {
              mapInstanceRef.current.flyTo([userLocation.lat, userLocation.lng], 18);
            }
          }}
          className="pointer-events-auto bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold px-3 py-1.5 rounded-full shadow-md border border-slate-200 flex items-center gap-1 active:scale-95 transition-all"
        >
          <MapPin className="w-3.5 h-3.5 text-[#7054db]" />
          <span>내 위치로 이동</span>
        </button>
      </div>

      {/* Floating Bottom Friend Tracker Card */}
      <div className="absolute bottom-4 left-4 right-4 z-10">
        <div className="bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-slate-100 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-[#7054db] text-white flex items-center justify-center shrink-0 shadow-sm">
              <Compass className="w-5 h-5 text-[#c9ff51]" />
            </div>
            <div className="overflow-hidden">
              <div className="text-sm font-extrabold text-[#111a35] flex items-center gap-1.5 truncate">
                {activeFriend ? (
                  <>
                    <span>{activeFriend.name}까지</span>
                    <span className="text-[#7054db]">
                      {activeDistanceMeters !== null
                        ? formatDistance(activeDistanceMeters)
                        : '--m'}
                    </span>
                  </>
                ) : (
                  <span>일행을 선택해 주세요</span>
                )}
              </div>
              <p className="text-[11px] text-slate-500 truncate mt-0.5">
                {activeFriend
                  ? `${activeFriend.statusMessage || '실시간 GPS 연동 중'}`
                  : '상단 로그인 버튼을 눌러 일행 선택'}
              </p>
            </div>
          </div>

          <button
            id="ar-nav-btn"
            onClick={onOpenAr}
            className="shrink-0 bg-[#111a35] hover:bg-slate-800 text-white font-bold text-xs px-4 py-3 rounded-xl shadow-lg transition-all flex items-center gap-1.5 active:scale-95"
          >
            <Navigation className="w-4 h-4 text-[#c9ff51] fill-[#c9ff51]" />
            <span>AR로 찾기</span>
          </button>
        </div>
      </div>
    </div>
  );
};
