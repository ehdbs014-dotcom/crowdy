export interface UserLocation {
  lat: number;
  lng: number;
  accuracy?: number;
  heading?: number;
  updatedAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  userCode: string;
  avatarBg: string;
  avatarInitial: string;
  email?: string;
  isLoggedIn: boolean;
}

export interface Friend {
  id: string;
  name: string;
  code: string;
  isOnline: boolean;
  avatarBg: string;
  avatarInitial: string;
  location: UserLocation;
  battery: number;
  statusMessage?: string;
}

export interface MeetingPoint {
  id: string;
  title: string;
  category: string;
  lat: number;
  lng: number;
  score: number;
  description: string;
}

export type ActiveTab = 'map' | 'ar' | 'meet' | 'friends';
